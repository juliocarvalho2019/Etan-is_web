export interface GasStationServices {
  id: number;
  name: string;
  start: string;
  end: string;
}
