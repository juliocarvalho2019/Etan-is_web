export interface Fuel {
  id?: number;
  fuel: string;
  price?: number;
}
