import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fuel-add',
  templateUrl: './fuel-add.component.html',
  styleUrls: ['./fuel-add.component.css']
})
export class FuelAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
