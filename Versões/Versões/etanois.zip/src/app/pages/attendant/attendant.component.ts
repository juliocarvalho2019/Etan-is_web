import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { UserService } from './../../services/user/user.service';

enum steps {
  login,
  gasStationChoose,
  gasStationAccessCode,
  gasStationRegister,
  gasStationRegisterDone
}

@Component({
  selector: 'app-attendant',
  templateUrl: './attendant.component.html',
  styleUrls: ['./attendant.component.css']
})
export class AttendantComponent implements OnInit {
  currentStep: steps = 0;
  username = '';
  password = '';

  gasStations = [{
    name: 'Posto Vasconcelos',
    flag: 'Branca',
    address: {
      street: 'Travessa da Luz',
      number: '165',
      neighborhood: 'São Luis',
      city: 'São Paulo',
      uf: 'SP'
    }
  }];

  constructor(
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit(): void {
  }

  back = () => {
    switch (this.currentStep) {
      case 1:
        this.currentStep = steps.login;
        break;

      case 2:
        this.currentStep = steps.gasStationChoose;
        break;
    }
  }

  login = () => {
    console.log(this.username, this.password);
    this.currentStep = steps.gasStationChoose;
  }

  accessCode = () => {
    this.currentStep = steps.gasStationAccessCode;
  }

  loginGasStation = () => {
    this.router.navigate(['/management']);
  }

  initGasStationRegister = () => {
    this.currentStep = steps.gasStationRegister;
  }

  finishGasStationRegister = () => {
    this.currentStep = steps.gasStationRegisterDone;
  }
}
