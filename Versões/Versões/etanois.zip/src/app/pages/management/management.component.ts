import { Component, OnInit } from '@angular/core';

enum menus {
  fuelManagement,
  servicesManagement,
  attendantManagement,
}

@Component({
  selector: 'app-management',
  templateUrl: './management.component.html',
  styleUrls: ['./management.component.css']
})
export class ManagementComponent implements OnInit {
  public activeMenu;

  availableFuels = [
    {
      id: 1,
      name: 'Gasolina Comum',
      price: 4.199
    },
    {
      id: 2,
      name: 'Alcool',
      price: 3.119
    },
    {
      id: 3,
      name: 'Gasolina Aditivada',
      price: 4.899
    },
  ];

  availableServices = [
    {
      id: 1,
      name: 'Horário de funcionamento',
      start: '08:00',
      end: '21:00'
    },
    {
      id: 2,
      name: 'Loja de Conveniência',
      start: '08:00',
      end: '21:00'
    },
    {
      id: 3,
      name: 'Restaurante',
      start: '08:00',
      end: '21:00'
    },
    {
      id: 4,
      name: 'Lava-jato',
      start: '08:00',
      end: '21:00'
    },
    {
      id: 5,
      name: 'Borracharia',
      start: '08:00',
      end: '21:00'
    },
  ];

  constructor() { }

  ngOnInit(): void {
    this.activeMenu = menus.fuelManagement;
  }

  changeMenu = (menuId: number) => {
    this.activeMenu = menuId;
  }

  editFuel = (id: number) => {
    console.log(`Editando o combustivel ${id}`);
  }

  removeFuel = (id: number) => {
    console.log(`Removendo o combustivel ${id}`);
  }

}
