import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationDone = false;

  constructor() { }

  ngOnInit(): void {
  }

  registration = () => {
    console.log('registration done');
    this.registrationDone = true;
  }

}
