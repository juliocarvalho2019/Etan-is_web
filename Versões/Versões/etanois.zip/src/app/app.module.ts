import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './pages/home/home.component';
import { AttendantComponent } from './pages/attendant/attendant.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { GoalsComponent } from './pages/goals/goals.component';
import { ManagementComponent } from './pages/management/management.component';
import { FuelCreateModalComponent } from './components/fuel-create-modal/fuel-create-modal.component';
import { FuelRemoveModalComponent } from './components/fuel-remove-modal/fuel-remove-modal.component';
import { FuelUpdateModalComponent } from './components/fuel-update-modal/fuel-update-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    AttendantComponent,
    RegistrationComponent,
    GoalsComponent,
    ManagementComponent,
    FuelCreateModalComponent,
    FuelRemoveModalComponent,
    FuelUpdateModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
