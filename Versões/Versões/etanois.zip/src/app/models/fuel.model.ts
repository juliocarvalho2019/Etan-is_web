export interface Fuel {
  id?: number;
  name: string;
  price?: number;
}
