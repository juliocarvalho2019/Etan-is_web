import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FuelCreateModalComponent } from './fuel-create-modal.component';

describe('FuelCreateModalComponent', () => {
  let component: FuelCreateModalComponent;
  let fixture: ComponentFixture<FuelCreateModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FuelCreateModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FuelCreateModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
