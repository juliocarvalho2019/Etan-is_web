import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fuel-create-modal',
  templateUrl: './fuel-create-modal.component.html',
  styleUrls: ['./fuel-create-modal.component.css']
})
export class FuelCreateModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
