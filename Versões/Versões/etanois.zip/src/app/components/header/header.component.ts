import { Router } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';

import { UserService } from './../../services/user/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  public subMenu = false;
  public user;
  private userSub;

  constructor(private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    this.userSub = this.userService.userChange.subscribe((data) => {
      this.user = data;
    });
  }

  ngOnDestroy(): void {
    this.userSub.unsubscribe();
  }

  openSubMenu = () => {
    this.subMenu = !this.subMenu;
  }

  logout = () => {
    this.userService.clearUser();
    this.subMenu = false;
    this.router.navigate(['/']);
  }
}
