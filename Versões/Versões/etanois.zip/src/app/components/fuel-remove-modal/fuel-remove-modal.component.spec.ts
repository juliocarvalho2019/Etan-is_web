import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FuelRemoveModalComponent } from './fuel-remove-modal.component';

describe('FuelRemoveModalComponent', () => {
  let component: FuelRemoveModalComponent;
  let fixture: ComponentFixture<FuelRemoveModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FuelRemoveModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FuelRemoveModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
