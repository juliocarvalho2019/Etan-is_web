import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fuel-remove-modal',
  templateUrl: './fuel-remove-modal.component.html',
  styleUrls: ['./fuel-remove-modal.component.css']
})
export class FuelRemoveModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
