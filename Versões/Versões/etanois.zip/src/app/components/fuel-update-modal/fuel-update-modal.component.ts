import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fuel-update-modal',
  templateUrl: './fuel-update-modal.component.html',
  styleUrls: ['./fuel-update-modal.component.css']
})
export class FuelUpdateModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
