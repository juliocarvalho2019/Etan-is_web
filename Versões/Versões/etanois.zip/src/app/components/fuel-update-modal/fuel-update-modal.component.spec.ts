import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FuelUpdateModalComponent } from './fuel-update-modal.component';

describe('FuelUpdateModalComponent', () => {
  let component: FuelUpdateModalComponent;
  let fixture: ComponentFixture<FuelUpdateModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FuelUpdateModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FuelUpdateModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
