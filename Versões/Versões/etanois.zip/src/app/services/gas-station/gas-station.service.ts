import { FuelStation } from './../../models/gas-station.model';
import { Injectable, Input, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GasStationService {
  @Input()
  public gasStation;

  @Output()
  public gasStationChange: EventEmitter<FuelStation> = new EventEmitter<FuelStation>();

  constructor() { }

  setGasStation = (gasStation: FuelStation) => {
    this.gasStation = gasStation;
    this.gasStationChange.emit(gasStation);
  }
}
