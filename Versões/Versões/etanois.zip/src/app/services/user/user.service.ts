import { Injectable, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { BASE_URL } from './../../utils/constants';
import { User } from './../../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  @Input()
  public user: User;

  @Output()
  public userChange: EventEmitter<User> = new EventEmitter<User>();

  constructor(private http: HttpClient) { }

  public getUser = () => {
    return this.user;
  }

  public clearUser = () => {
    this.user = undefined;
  }

  public login = (username: string, password: string) => {
    // return this.http.post<User>(`${BASE_URL}/auth/token`, { username, password })
    //   .subscribe((data) => {
    //     if (data) {
    //       this.user = data;
    //     }
    //   });
    this.user = {
      name: 'Carvalho',
      username: 'carvalho',
      email: 'carvalho@email.com.br',
      password: '123456',
      new_password: '123456',
      old_password: '123456'
    };
  }
}
